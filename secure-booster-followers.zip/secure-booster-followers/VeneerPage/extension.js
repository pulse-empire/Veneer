document.getElementById('boostButton').addEventListener('click', ()=>{
  alert('Make sure you are already logged into the selected service! If you are not already logged in, this tool won\'t work');
  alert('If you are already logged in, then you are now free to log out from your account. Wait for 12 hours until you log in again to allow the tool to work seamlessly')
});