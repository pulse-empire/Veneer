document.getElementById('openPopupAsTab').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].id) {
            chrome.runtime.sendMessage({
                action: 'checkAndOpenPopup',
                tabId: tabs[0].id
            });
        } else {
            console.error("Could not get current tab ID.");
        }
    });
});

const rulesCheckbox = document.getElementById('rulesCheckbox');
const openPopupAsTabButton = document.getElementById('openPopupAsTab');

rulesCheckbox.addEventListener('change', function () {
    if (this.checked) {
        openPopupAsTabButton.classList.add('enabled');
        openPopupAsTabButton.style.opacity = 1;
        openPopupAsTabButton.style.cursor = 'pointer';
    } else {
        openPopupAsTabButton.classList.remove('enabled');
        openPopupAsTabButton.style.opacity = 0.5;
        openPopupAsTabButton.style.cursor = 'not-allowed';
    }
});

openPopupAsTabButton.addEventListener('click', function (event) {
    if (!rulesCheckbox.checked) {
        event.preventDefault();
    }
});